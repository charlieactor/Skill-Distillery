package examples;

import javax.swing.JFrame;

public class Notepad1 extends JFrame {

    public Notepad1() {
        super("Notepad");
        setSize(300, 400);
        setVisible(true);
    }

    public static void main(String[] arg) {
        new Notepad1();
    }
}
