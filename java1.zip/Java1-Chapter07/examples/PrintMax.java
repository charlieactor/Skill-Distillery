package examples;

public class PrintMax {
    public static void main(String[] args) {
        int iMax = 2147483647;
        long lMax = 9223372036854775807L;
        float fMax = 3.40282347e38F;
        double dMax = 1.79769313486231570e308;

        System.out.println(iMax);
        System.out.println(lMax);
        System.out.println(fMax);
        System.out.println(dMax);
    }
}
