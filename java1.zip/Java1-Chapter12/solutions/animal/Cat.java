package solutions.animal;

public class Cat {
    String meow;

    public Cat() {
        meow = "mew";
    }

    @Override
    public String toString() {
        return meow;
    }
}