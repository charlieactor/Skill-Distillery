package solutions.animal;

public class Dog {
    String bark;

    public Dog() {
        bark = "woof";
    }

    @Override
    public String toString() {
        return bark;
    }
}