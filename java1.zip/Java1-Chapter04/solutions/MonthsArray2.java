package solutions;

public class MonthsArray2 {
    public static void main(String args[]) {
		String[] months = { "January", "February", "March", "April", 
				"May", "June", "July", "August", "September",
				"October", "November", "December" };

		System.out.println(months[11]);
    }
}
