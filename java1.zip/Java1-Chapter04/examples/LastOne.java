package examples;

public class LastOne {
    public static void main(String args[]) {
        System.out.println(args[args.length - 1]);
    }
}
