package solutions;

public class Month {
	String name;
	String abbreviation;
	int numDays;
	
	public void display() {
		System.out.println(name + " has " + numDays + " days");
	}
}
