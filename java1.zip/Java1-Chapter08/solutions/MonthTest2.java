package solutions;

public class MonthTest2 {
	public static void main(String[] args) {
		Month2 dec = new Month2();
		dec.name = "December";
		dec.abbreviation = "Dec";
		dec.numDays = 31;
		
		dec.display(true);
	}
}
