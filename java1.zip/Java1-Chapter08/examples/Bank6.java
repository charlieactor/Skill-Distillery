package examples;

public class Bank6 {

    public static void main(String[] args) {
        new Customer6("Jim", "Stewart");
        new Customer6("Joan", "Stewart", 500.0);
    }
}
