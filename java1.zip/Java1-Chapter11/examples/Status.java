package examples;

public enum Status {
    ON, OFF
}