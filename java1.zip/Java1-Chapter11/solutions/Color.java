package solutions;

public enum Color {
    RED, YELLOW, GREEN, BLUE, WHITE
}