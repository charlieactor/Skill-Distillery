package solutions;

public class Employee {
    String firstName;
    String lastName;
    String phone;
    String deptCode;
    float salary;
}
