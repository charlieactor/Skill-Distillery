package solutions;

public class LetterHouse {
    public static void main(String[] args) {
        System.out.println("                  AAAA");
        System.out.println("        PPPPPPPP  A  A");
        System.out.println("      P          PA  A");
        System.out.println("    P               PA");
        System.out.println("  P                   P");
        System.out.println("PW  WWWW         WWWW  WP");
        System.out.println(" W  W  W  AAAAA  W  W  W");
        System.out.println(" W  WWWW  A   A  WWWW  W");
        System.out.println(" W        A  AA        W");
        System.out.println(" W        A   A        W");
        System.out.println(" WWWWWWWWWWWWWWWWWWWWWWW");
    }
}
