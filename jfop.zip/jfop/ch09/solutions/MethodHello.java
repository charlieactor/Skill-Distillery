package solutions;

public class MethodHello {
    public static void main(String[] args) {
        printHello();
    }

    public static void printHello() {
        System.out.println("Hello from the printHello() method!");
    }
}
