package solutions;

public class AgeInitial {

    public static void main(String[] args) {

        int age = 45;
        char mi = 'Q';

        System.out.println("John " + mi + ". Public: Age: " + age + ".");
    }
}
