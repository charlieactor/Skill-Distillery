package solutions;

public class Mult2 {
    public static void main(String[] args) {

        int i = 0;

        for (i = 0; i <= 16; i = i + 1) {
            System.out.println(i + ":\t" + 2 * i);
        }
    }
}
