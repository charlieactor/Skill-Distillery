package solutions;

public class TwoPrints {
    public static void main(String[] args) {
        System.out.println("Hello,");
        System.out.println("Bill");
    }
}