package solutions;

public class HelloStars {
    public static void main(String[] args) {
        System.out.println("*****************************************");
        System.out.println("*\t\tHello,\t\t\t*");
        System.out.println("*\t\tBill\t\t\t*");
        System.out.println("*****************************************");
    }
}