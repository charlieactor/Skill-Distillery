//  A simple Hello, world program
//  Note: The file name must be the same as the
//  class name, with a .java extension.  

package solutions;

public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello, world");
    }
}