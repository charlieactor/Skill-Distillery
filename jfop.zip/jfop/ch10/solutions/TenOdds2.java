package solutions;

public class TenOdds2 {
    public static void main(String[] args) {
        int[] odds = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19 };

        for (int i = 0; i < odds.length; i++) {
            System.out.println(odds[i]);
        }
    }
}
