package solutions;

public class TenOdds1 {
    public static void main(String[] args) {
        int[] odds = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19 };

        System.out.println("The first element of the array is: "
                + odds[0]);
        System.out.println("The last element of the array is: "
                + odds[9]);
    }
}
